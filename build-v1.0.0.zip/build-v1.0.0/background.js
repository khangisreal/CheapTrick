async function updateContentScripts(domains) {
  try {
    // Retrieve previously registered content scripts
    const registered = await chrome.scripting.getRegisteredContentScripts();
    const registeredIds = registered.map(s => s.id);

    // Unregister all existing scripts
    if (registeredIds.length > 0) {
      await chrome.scripting.unregisterContentScripts({ ids: registeredIds });
    }

    if (domains.length === 0) return;

    // Register dynamic content scripts for specified target domains (runs in MAIN world at document_start)
    const scripts = domains.map((domain, index) => ({
      id: `domain_${index}_${domain}`,
      matches: [`*://*.${domain}/*`, `*://${domain}/*`],
      js: ["injected.js"],
      runAt: "document_start",
      world: "MAIN"
    }));

    await chrome.scripting.registerContentScripts(scripts);
    console.log("Updated blocked domain list:", domains);
  } catch (err) {
    console.error("Error updating content scripts:", err);
  }
}

// Trigger script registration on extension install or update
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get({ disabledDomains: [] }, (data) => {
    updateContentScripts(data.disabledDomains);
  });
});

// Listen for messages from popup to update registered domains dynamically
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "updateDomains") {
    updateContentScripts(request.domains);
    sendResponse({ status: "ok" });
  }
});