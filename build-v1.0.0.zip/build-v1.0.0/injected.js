(function () {
  // List of event types to intercept and prevent from firing
  const BLOCKED_EVENTS = [
    "blur", 
    "visibilitychange", 
    "mouseleave", 
    "pagehide", 
    "fullscreenchange", 
    "webkitfullscreenchange", 
    "mozfullscreenchange", 
    "MSFullscreenChange"
  ];

  const originalWindowAddEventListener = window.addEventListener;
  const originalDocumentAddEventListener = document.addEventListener;

  // 1. Override addEventListener on window to block targeted event listeners
  window.addEventListener = function (type, listener, options) {
    if (BLOCKED_EVENTS.includes(type)) {
      return;
    }
    return originalWindowAddEventListener.apply(this, arguments);
  };

  // 2. Override addEventListener on document to block targeted event listeners
  document.addEventListener = function (type, listener, options) {
    if (BLOCKED_EVENTS.includes(type)) {
      return;
    }
    return originalDocumentAddEventListener.apply(this, arguments);
  };

  // 3. Block direct handler assignments (e.g., window.onblur = ...)
  Object.defineProperty(window, "onblur", {
    get: () => null,
    set: () => true,
    configurable: true
  });

  Object.defineProperty(document, "onvisibilitychange", {
    get: () => null,
    set: () => true,
    configurable: true
  });

  Object.defineProperty(document, "onfullscreenchange", {
    get: () => null,
    set: () => true,
    configurable: true
  });

  // 4. Mock page state APIs to always report active focus and visibility
  Object.defineProperty(document, "visibilityState", {
    get: () => "visible",
    configurable: true,
  });

  Object.defineProperty(document, "hidden", {
    get: () => false,
    configurable: true,
  });

  Object.defineProperty(document, "hasFocus", {
    value: () => true,
    writable: false,
    configurable: true,
  });

  // 5. Intercept and stop propagation of browser-native events in the capture phase
  BLOCKED_EVENTS.forEach((eventName) => {
    window.addEventListener(
      eventName,
      (e) => {
        e.stopImmediatePropagation();
        e.stopPropagation();
      },
      true
    );
    document.addEventListener(
      eventName,
      (e) => {
        e.stopImmediatePropagation();
        e.stopPropagation();
      },
      true
    );
  });
})();