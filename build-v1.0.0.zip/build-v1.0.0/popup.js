document.addEventListener("DOMContentLoaded", () => {
  const domainInput = document.getElementById("domainInput");
  const addBtn = document.getElementById("addBtn");
  const domainList = document.getElementById("domainList");

  function renderDomains(domains) {
    domainList.innerHTML = "";
    domains.forEach((domain, index) => {
      const li = document.createElement("li");
      li.textContent = domain;

      const delBtn = document.createElement("button");
      delBtn.textContent = "Xóa";
      delBtn.className = "del-btn";
      delBtn.onclick = () => saveAndNotify(domains.filter((_, i) => i !== index));

      li.appendChild(delBtn);
      domainList.appendChild(li);
    });
  }

  function saveAndNotify(domains) {
    chrome.storage.sync.set({ disabledDomains: domains }, () => {
      // Gửi tín hiệu cho background.js cập nhật lại quy tắc chặn
      chrome.runtime.sendMessage({ action: "updateDomains", domains: domains }, () => {
        renderDomains(domains);
      });
    });
  }

  addBtn.addEventListener("click", () => {
    let domain = domainInput.value.trim().toLowerCase();
    domain = domain.replace(/^(https?:\/\/)?(www\.)?/, "").split("/")[0];

    if (!domain) return;

    chrome.storage.sync.get({ disabledDomains: [] }, (data) => {
      const domains = data.disabledDomains;
      if (!domains.includes(domain)) {
        domains.push(domain);
        domainInput.value = "";
        saveAndNotify(domains);
      }
    });
  });

  chrome.storage.sync.get({ disabledDomains: [] }, (data) => {
    renderDomains(data.disabledDomains);
  });
});